<footer class="main-footer">
    <div class="float-right d-none d-sm-inline">
        Admin Panel
    </div>
    <strong>Iqbolshoh &copy;2025 <a href="https://Iqbolshoh.uz">Iqbolshoh.uz</a>.</strong> All rights reserved.
</footer>