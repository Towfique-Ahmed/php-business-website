  <!-- jQuery -->
  <script src="../assets/js/jquery.min.js"></script>

  <!-- Bootstrap 4 -->
  <script src="../assets/js/bootstrap.bundle.min.js"></script>

  <!-- SweetAlert2 -->
  <script src="../assets/js/sweetalert2.min.js"></script>

  <!-- Toastr -->
  <script src="../assets/js/toastr.min.js"></script>
  <script src="../assets/js/adminlte.min.js"></script>